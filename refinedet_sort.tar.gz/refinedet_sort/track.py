import os
import argparse
import cv2
import numpy as np
from refinedet import RefineDet
from sort import Sort
from PIL import Image
import matplotlib.pyplot as plt
import time

def parse_args():
    '''parse args'''
    parser = argparse.ArgumentParser()
    parser.add_argument('--cpu_id', type=int, default=0, help='cpu id')
    parser.add_argument('--labelmap_file',
                        default='/home/ambavm/object_track/refinedet_sort/model/labelmap_voc.prototxt')
    parser.add_argument('--model_def',
                        default='/home/ambavm/object_track/refinedet_sort/model/deploy.prototxt')
    parser.add_argument('--image_resize', default=512, type=int)
    parser.add_argument('--model_weights',
                        default='/home/ambavm/object_track/refinedet_sort/model/refinedet.caffemodel')
    parser.add_argument('--det_conf_thresh', default=0.25, type=float)
    parser.add_argument('--seq_dir',default="/home/ambavm/object_track/refinedet_sort/sequence/")
    parser.add_argument('--sort_max_age',default=5,type=int)
    parser.add_argument('--sort_min_hit',default=3,type=int)
    return parser.parse_args()


if __name__=="__main__":
    args=parse_args()
    Detector=RefineDet(args.cpu_id,args.model_def, args.model_weights,args.image_resize, args.labelmap_file)
    mot_tracker = Sort(args.sort_max_age,args.sort_min_hit) 
    seqDir=args.seq_dir
    videos=os.listdir(seqDir)
    # images.sort(key=str.lower)
    total_time = 0.0
    colours = np.random.rand(32,3)*255
    for video_name in videos:
        image_path=os.path.join(seqDir,video_name)
        cap = cv2.VideoCapture(image_path)
        while cap.isOpened():
            ret, image = cap.read()
            if ret == True:
               image = image/ 255.0
               result = Detector.detect(image,args.det_conf_thresh)
               height=image.shape[0]
               width=image.shape[1]
               result=np.array(result)

               # print(result)
               det=result[:,0:5]
               det[:,0]=det[:,0]*width
               det[:,1]=det[:,1]*height
               det[:,2]=det[:,2]*width
               det[:,3]=det[:,3]*height

               start_time = time.time()
               trackers = mot_tracker.update(det)
               cycle_time = time.time() - start_time
               total_time += cycle_time
               print("tracking time :",total_time)

               for d in trackers:
                    xmin=int(d[0])
                    ymin=int(d[1])
                    xmax=int(d[2])
                    ymax=int(d[3])
                    label=int(d[4])
                    cv2.rectangle(image,(xmin,ymin),(xmax,ymax),(int(colours[label%32,0]),int(colours[label%32,1]),int(colours[label%32,2])),1)
                    cv2.imshow("image",image)
                    cv2.waitKey(1)

      
    
    
